let currentPlayer = 'X';
let gameBoard = Array(9).fill('');
let gameOver = false;

const cells = document.querySelectorAll('.cell');
const status = document.getElementById('status');

cells.forEach(cell => {
  cell.addEventListener('click', handleClick);
});

function handleClick(e) {
  const index = e.target.dataset.index;
  if (gameBoard[index] !== '' || gameOver) return;

  gameBoard[index] = currentPlayer;
  e.target.textContent = currentPlayer;

  if (checkWinner()) {
    status.textContent = `Player ${currentPlayer} wins!`;
    gameOver = true;
  } else if (gameBoard.every(cell => cell !== '')) {
    status.textContent = "It's a draw!";
    gameOver = true;
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    status.textContent = `Player ${currentPlayer}'s turn`;
  }
}

function checkWinner() {
  const winCombos = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];

  return winCombos.some(combo => {
    return combo.every(index => gameBoard[index] === currentPlayer);
  });
}

function restartGame() {
  gameBoard.fill('');
  cells.forEach(cell => (cell.textContent = ''));
  currentPlayer = 'X';
  gameOver = false;
  status.textContent = `Player ${currentPlayer}'s turn`;
}
