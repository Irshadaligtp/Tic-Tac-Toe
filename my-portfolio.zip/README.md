# 👨‍💻 My Portfolio

Welcome to my GitHub portfolio! I'm a passionate developer interested in AI, ML, and Web Development. Here you'll find some of my personal and academic projects.

## 🚀 Projects

### 1. [Tic-Tac-Toe Game](./tic-tac-toe-game/)
A simple 2-player browser-based Tic-Tac-Toe game built with HTML, CSS, and JavaScript.

### 2. Placeholder Projects
- AI/ML Classifier (Coming Soon)
- Weather App (Coming Soon)

## 🧠 Skills

- Languages: Python, JavaScript, HTML, CSS
- Tools: Git, GitHub, VS Code
- Frameworks: Bootstrap, React (learning), TensorFlow (learning)

## 📫 Contact

- 📧 Email: your.email@example.com
- 🔗 LinkedIn: [YourLinkedIn](https://linkedin.com/in/yourprofile)
